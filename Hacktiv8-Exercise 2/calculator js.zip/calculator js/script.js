function result(){
    var numbera = document.querySelector(".number1").value;
    var numberb = document.querySelector(".number2").value;
    var kalkulator = document.querySelector(".kalkulator").value;
    var total=0; 
    console.log(typeof numbera)
    console.log(kalkulator)
    if(kalkulator=="+"){
        total = Number(numbera) + Number(numberb);
    }
    else if(kalkulator=="-"){
        total = Number(numbera) - Number(numberb);
    }
    else if(kalkulator=="*"){
        total = Number(numbera) * Number(numberb);
    }
    else if(kalkulator==":"){
        total = Number(numbera) / Number(numberb);
    }
    document.querySelector(".result").innerHTML= total;
}